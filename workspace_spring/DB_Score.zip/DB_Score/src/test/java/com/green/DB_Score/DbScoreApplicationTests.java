package com.green.DB_Score;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbScoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
