package com.green.DBTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
