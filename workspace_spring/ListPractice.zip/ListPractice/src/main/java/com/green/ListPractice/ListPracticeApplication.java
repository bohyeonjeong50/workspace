package com.green.ListPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListPracticeApplication.class, args);
	}

}
