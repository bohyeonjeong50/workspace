package com.green.BasicBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
